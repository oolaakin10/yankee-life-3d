const http = require("http");
const fs = require("fs");
const path = require("path");
const WebSocket = require("ws");
const PORT = Number(process.env.PORT || 3001);
const ROOT = __dirname;
const rooms = new Map();
const mime = { ".html":"text/html; charset=utf-8", ".css":"text/css; charset=utf-8", ".js":"text/javascript; charset=utf-8", ".json":"application/json; charset=utf-8", ".png":"image/png", ".svg":"image/svg+xml" };
const server = http.createServer((req, res) => {
  const pathname = new URL(req.url, `http://${req.headers.host || "localhost"}`).pathname;
  if (pathname === "/health") { res.writeHead(200, {"content-type":"application/json"}); return res.end(JSON.stringify({ok:true,rooms:rooms.size})); }
  const requested = pathname === "/" ? "/index.html" : pathname;
  const file = path.resolve(ROOT, "." + requested);
  if (!file.startsWith(ROOT + path.sep) && file !== path.join(ROOT,"index.html")) { res.writeHead(403); return res.end("Forbidden"); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, {"content-type":"text/plain; charset=utf-8"}); return res.end("Not found"); }
    res.writeHead(200, {"content-type":mime[path.extname(file)] || "application/octet-stream", "x-content-type-options":"nosniff"}); res.end(data);
  });
});
const wss = new WebSocket.Server({server});
function send(ws, data) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data)); }
function snapshot(room, exceptId) { const out = {}; for (const [id,p] of room.players) if (id !== exceptId) out[id] = {name:p.name,x:p.x,y:p.y,avatar:p.avatar}; return out; }
function broadcast(room, data, except) { for (const p of room.players.values()) if (p.ws !== except) send(p.ws,data); }
wss.on("connection", ws => {
  ws.id = Math.random().toString(36).slice(2,10); ws.room = null; ws.lastMove = 0;
  ws.on("message", raw => {
    let msg; try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (msg.type === "join") {
      const roomName = String(msg.room || "").toUpperCase().replace(/[^A-Z0-9_-]/g,"").slice(0,24);
      if (!roomName) return send(ws,{type:"error",message:"Enter a valid room code."});
      let room = rooms.get(roomName); if (!room) { room={players:new Map()}; rooms.set(roomName,room); }
      if (room.players.size >= 2) return send(ws,{type:"roomFull"});
      ws.room = roomName; const p = {ws,id:ws.id,name:String(msg.name||"Player").slice(0,20),avatar:String(msg.avatar||"🧑").slice(0,8),x:.5,y:.7};
      room.players.set(ws.id,p); send(ws,{type:"welcome",id:ws.id,players:snapshot(room,ws.id)}); broadcast(room,{type:"players",players:snapshot(room)},ws); return;
    }
    if (msg.type === "move" && ws.room) {
      const now = Date.now(); if (now-ws.lastMove < 35) return; ws.lastMove=now;
      const room=rooms.get(ws.room), p=room && room.players.get(ws.id); if (!p) return;
      p.x=Math.max(0,Math.min(1,Number(msg.x)||0)); p.y=Math.max(0,Math.min(1,Number(msg.y)||0));
      p.name=String(msg.name||p.name).slice(0,20); p.avatar=String(msg.avatar||p.avatar).slice(0,8);
      broadcast(room,{type:"playerMoved",id:ws.id,name:p.name,x:p.x,y:p.y,avatar:p.avatar},ws);
    }
  });
  ws.on("close",()=>{ if (!ws.room) return; const room=rooms.get(ws.room); if (!room) return; room.players.delete(ws.id); broadcast(room,{type:"left",id:ws.id}); if (!room.players.size) rooms.delete(ws.room); });
});
server.listen(PORT,"0.0.0.0",()=>console.log(`YANKEE LIFE 3D running on port ${PORT}`));
