# YANKEE LIFE — Public 3D Multiplayer Prototype

Free browser-based 3D city game prototype. It serves the game and its two-player WebSocket server from one public service. No payments or checkout are included.

## Publish publicly (Render + GitHub)
1. Create a GitHub repository and upload all files in this folder (including `render.yaml`).
2. Sign in to Render and choose **New → Blueprint**.
3. Connect the repository containing `render.yaml` and deploy the Blueprint. Render will install dependencies and start the Node server.
4. When Render gives you a public `https://...onrender.com` URL, open that URL. The game automatically uses the matching secure `wss://` URL for multiplayer.
5. Send that same website link to your friend. Both players enter the same room code and click **Connect**.

Render free services may sleep after inactivity; the first visit after sleeping can take a little time. Availability and plan terms can change.

## Local test
Requires Node.js 18+. Run `npm install` and `npm start`, then open http://localhost:3001 in two browser windows. Use the same room code.

## Controls
- Move: W A S D or arrow keys
- Drag the 3D scene: adjust camera
- Press E near a marked destination: interact

## Prototype limitations
This is an early two-player prototype with basic geometric city assets and position relay. It is not a production MMO and does not include accounts, chat, moderation, persistent saves, server-authoritative movement, or room-code authentication. Anyone who knows a room code may join it.
